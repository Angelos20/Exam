//exercice 1
       function resoudre() {
    var a = parseFloat(document.getElementById("nombre1").value);
    var b = parseFloat(document.getElementById("nombre2").value);
    var c = parseFloat(document.getElementById("nombre3").value);
    var bString = b < 0 ? "- " + (-b) : "+ " + b;
    var X1;
    var X2;
    var delta = (b * b) - 4 * (a * c);
  
    if (delta == 0) {
        X1 = -b / (2 * a);
        document.getElementById("resultatresoudre").value = "Résolution de l'équation "+a+"x²+"+b+"x+"+c+"=0\n Calculons d'abord:\n   delta=("+b+"×"+b+")-(4×"+a+"×"+c+")="+delta+"\n Comme deltat=0,\n Alors on a une racine unique\n X1=X2=(-"+b+"-√"+delta+")/(2×"+a+")="+X1;
    } 
    else if (delta > 0) {
        X1 = (-b - Math.sqrt(delta)) / (2 * a);
        X2 = (-b + Math.sqrt(delta)) / (2 * a);
        document.getElementById("resultatresoudre").value = "Résolution de l'équation "+a+"x²+"+b+"x+"+c+"=0\n  Calculons d'abord:\n   delta=("+b+"×"+b+")-(4×"+a+"×"+c+")="+delta+"\n Comme delta\>0 et √delta="+Math.sqrt(delta)+"\n Alors on a deux racine distinctes:\n X1=(-("+b+")-√"+delta+")/(2×"+a+")="+X1+"\n X2=(-("+b+")+√"+delta+")/(2×"+a+")="+X2+"\n Ainsi on a deux solutions X1="+X1+" et X2="+X2;
    } 
    else {
        document.getElementById("resultatresoudre").value = "Résolution de l'équation "+a+"x²+"+b+"x+"+c+"=0\n Calculons d'abord:\n   delta=("+b+"×"+b+")-(4×"+a+"×"+c+")="+delta+"\n Comme delta\< 0\n Donc la solution est vide.";
    }
} 

//exercice 2

 function calIntI1()
 {
     let tension= parseFloat(document.getElementById("tension").value);
     let resistance1= parseFloat(document.getElementById("resistance1").value);
     
   var Int1 = tension/resistance1;
   document.getElementById("resultatcal").value= Int1;
 }
 
    function calIntI2()
 {
   let tension = parseFloat(document.getElementById("tension").value) ;
   let resistance2 = parseFloat(document.getElementById("resistance2").value);
   let Int2 = tension / resistance2 ; 
   
document.getElementById("resultatcal").value = Int2;
 } 
 
 function calIntI3()
 {
     var tension = parseFloat(document.getElementById("tension").value);
     var resistance2 = parseFloat(document.getElementById("resistance2").value);
     var Int3 = tension/resistance3;
 document.getElementById("resultatcal").value = Int3;
 }
 
 function caltensU1()
 {
    var tension = parseFloat(document.getElementById("tension").value);
    var intI1=
     
 }